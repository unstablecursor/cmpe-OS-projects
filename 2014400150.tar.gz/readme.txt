Recep Deniz Aksoy 2014400150
Compile with:
$ g++ -std=c++11 main.cpp -o project2
Run with(Don't forget to move executable to input file folder):
$ ./project2 definition.txt output.txt
